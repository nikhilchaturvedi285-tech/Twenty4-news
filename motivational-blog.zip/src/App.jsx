import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Post from './pages/Post'

export default function App(){
  return (
    <div>
      <header className="bg-white shadow">
        <div className="container flex items-center justify-between py-4">
          <Link to="/" className="text-2xl font-bold">सपनों की उड़ान</Link>
          <nav>
            <Link to="/" className="mr-4">Home</Link>
            <a href="#" className="mr-4">About</a>
            <a href="#" className="">Contact</a>
          </nav>
        </div>
      </header>

      <main className="container py-8">
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/post/:slug" element={<Post/>} />
        </Routes>
      </main>

      <footer className="bg-white border-t mt-12">
        <div className="container py-6 text-center text-sm text-gray-600">© {new Date().getFullYear()} सपनों की उड़ान · Built with ❤️</div>
      </footer>
    </div>
  )
}

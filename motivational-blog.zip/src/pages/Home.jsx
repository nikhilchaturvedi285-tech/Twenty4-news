import React, {useEffect, useState} from 'react'
import { Link } from 'react-router-dom'
import postsHelper from '../utils/posts'

export default function Home(){
  const [posts, setPosts] = useState([])
  useEffect(()=>{
    postsHelper.getAllPosts().then(setPosts)
  },[])
  return (
    <div>
      <section className="mb-8">
        <h1 className="text-3xl font-bold mb-2">स्वागत है — सपनों की उड़ान</h1>
        <p className="text-gray-700">यहाँ आपको प्रेरणादायक कहानियाँ और जीवन के सबक मिलेंगे — सरल हिंदी में।</p>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">नवीनतम पोस्ट</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {posts.map(p => (
            <article key={p.slug} className="bg-white p-4 rounded shadow">
              <h3 className="text-xl font-semibold"><Link to={`/post/${p.slug}`}>{p.title}</Link></h3>
              <p className="text-sm text-gray-600">{p.date}</p>
              <p className="mt-2 text-gray-700">{p.excerpt}</p>
              <Link to={`/post/${p.slug}`} className="inline-block mt-3 text-indigo-600">Read more →</Link>
            </article>
          ))}
        </div>
      </section>
    </div>
  )
}

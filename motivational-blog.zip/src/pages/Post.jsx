import React, {useEffect, useState} from 'react'
import { useParams, Link } from 'react-router-dom'
import postsHelper from '../utils/posts'
import { marked } from 'marked'

export default function Post(){
  const { slug } = useParams()
  const [post, setPost] = useState(null)
  useEffect(()=>{
    postsHelper.getPostBySlug(slug).then(setPost)
  },[slug])
  if(!post) return <div>Loading...</div>
  return (
    <article className="prose lg:prose-xl">
      <h1>{post.title}</h1>
      <p className="text-sm text-gray-600">{post.date}</p>
      <div dangerouslySetInnerHTML={{__html: marked.parse(post.content)}} />
      <p><Link to="/">← Back to Home</Link></p>
    </article>
  )
}

const postsData = import.meta.glob('../posts/*.md', { as: 'raw' })

function parseMeta(raw){
  const lines = raw.split('\n')
  const meta = {}
  let i = 0
  while(i < 10 && i < lines.length){
    const line = lines[i].trim()
    if(line.includes(':')){
      const [k, ...rest] = line.split(':')
      meta[k.trim().toLowerCase()] = rest.join(':').trim()
      i++
    } else break
  }
  const content = lines.slice(i).join('\n')
  return {meta, content}
}

export default {
  async getAllPosts(){
    const entries = Object.entries(postsData)
    const arr = await Promise.all(entries.map(async ([path, resolver])=>{
      const raw = await resolver()
      const {meta, content} = parseMeta(raw)
      const slug = path.split('/').pop().replace('.md','')
      return {
        slug,
        title: meta.title || 'Untitled',
        date: meta.date || '',
        excerpt: meta.excerpt || (content.slice(0,150) + '...'),
        content
      }
    }))
    return arr.sort((a,b)=> new Date(b.date) - new Date(a.date))
  },
  async getPostBySlug(slug){
    const all = await this.getAllPosts()
    return all.find(p=>p.slug === slug)
  }
}
